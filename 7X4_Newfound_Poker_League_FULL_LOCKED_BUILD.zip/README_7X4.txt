7X4 — Newfound Poker League FULL LOCKED BUILD

Built from the locked TRUE FULL v5 base.

Applied only the requested header correction:
- Header shows logo + Newfound Poker League
- Flame removed
- Duplicate/bottom header removed
- Header subtitle line removed
- Full original app body/layout/functionality preserved

Open index.html to run.
